from flask import Flask, render_template, request
app = Flask(__name__)
def weighted_astar(maze, start, end, weight):
    def heuristic(node):
        return ((node[0] - end[0]) ** 2 + (node[1] - end[1]) ** 2) ** 0.5

    open_set = {start}
    closed_set = set()
    g_score = {start: 0}
    f_score = {start: g_score[start] + weight * heuristic(start)}
    came_from = {}

    while open_set:
        current = min(open_set, key=lambda node: f_score[node])

        if current == end:
            path = []
            while current in came_from:
                path.insert(0, current)
                current = came_from[current]
            return path

        open_set.remove(current)
        closed_set.add(current)

        for neighbor in get_neighbors(current, maze):
            if neighbor in closed_set:
                continue

            tentative_g_score = g_score[current] + 1

            if neighbor not in open_set or tentative_g_score < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g_score
                f_score[neighbor] = g_score[neighbor] + weight * heuristic(neighbor)

                if neighbor not in open_set:
                    open_set.add(neighbor)

    return None

def get_neighbors(node, maze):
    neighbors = []
    for i, j in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
        new_node = (node[0] + i, node[1] + j)
        if 0 <= new_node[0] < len(maze) and 0 <= new_node[1] < len(maze[0]) and maze[new_node[0]][new_node[1]] == 0:
            neighbors.append(new_node)
    return neighbors

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/solve1', methods=['POST'])
def solve1():
    maze_input = request.form['maze']
    maze = [list(map(int, row.split())) for row in maze_input.strip().split('\n')]
    start = (0, 0)
    end = (4, 10)
    weight = 1.5
    path = weighted_astar(maze, start, end, weight)
    if path is not None:
        return render_template('solution.html', maze=maze, path=path)
    else:
        return "No se pudo encontrar una solución al laberinto."

@app.route('/solve2', methods=['POST'])
def solve2():
    maze_input = request.form['maze']
    maze = [list(map(int, row.split())) for row in maze_input.strip().split('\n')]
    start = (0, 2)
    end = (10, 3)
    weight = 1.5
    path = weighted_astar(maze, start, end, weight)
    if path is not None:
        return render_template('solution.html', maze=maze, path=path)
    else:
        return "No se pudo encontrar una solución al laberinto."
    
@app.route('/solve3', methods=['POST'])
def solve3():
    maze_input = request.form['maze']
    maze = [list(map(int, row.split())) for row in maze_input.strip().split('\n')]
    start = (0, 2)
    end = (4, 8)
    weight = 1.5
    path = weighted_astar(maze, start, end, weight)
    if path is not None:
        return render_template('solution.html', maze=maze, path=path)
    else:
        return "No se pudo encontrar una solución al laberinto."

if __name__ == '__main__':
    app.run(debug=True)
